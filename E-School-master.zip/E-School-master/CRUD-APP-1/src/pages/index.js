export { default as LoginPage } from './LoginPage';
export { default as RegisterPage } from './RegisterPage';
export { default as ChangePasswordPage } from './ChangePasswordPage';
export { default as AddNewStudent } from './AddNewStudent';
export { default as StudentsPage } from './StudentsPage';
export { default as Settings } from './Settings';
export { default as DashboardPage } from './DashboardPage';
export { default as UpdateStudent } from './UpdateStudent';
